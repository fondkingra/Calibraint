'use strict';

const assetTransfer = require('./lib/assetTransfer');

module.exports.AssetTransfer = assetTransfer;
module.exports.contracts = [assetTransfer];
